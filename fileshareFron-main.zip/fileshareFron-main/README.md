# File Sharing web Application

Simple file sharing web app with drag and drop file upload

Preview

![ezgif com-gif-maker](https://user-images.githubusercontent.com/79139812/174277080-cc9afcfd-406f-49ac-a2fc-93322a95c7b6.gif)


Full Project

https://user-images.githubusercontent.com/79139812/174277390-6aa691a2-05aa-40ab-a049-e2238dd1d862.mp4
